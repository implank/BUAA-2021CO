100个文件，每个文件.data创建100个标签，.text创建100个标签和200个引用
把assembler.exe和linker.exe复制到目录下，双击action.bat运行